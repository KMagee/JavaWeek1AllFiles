package org.datafactory.values;

public interface NameDataValues {
	String[] getFirstNames();

	String[] getLastNames();

	String[] getPrefixes();

	String[] getSuffixes();
}
