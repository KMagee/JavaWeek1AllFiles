package org.datafactory.values;

public interface ContentDataValues {
	String[] getWords();

	String[] getBusinessTypes();

	String[] getEmailHosts();

	String[] getTlds();
}
