package org.datafactory.values;

public interface AddressDataValues {

	String[] getStreetNames();

	String[] getCities();

	String[] getAddressSuffixes();
}
